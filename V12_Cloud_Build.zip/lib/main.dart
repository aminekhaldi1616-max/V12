import 'package:flutter/material.dart';
import 'package:video_player/video_player.dart';

void main() => runApp(const V12App());

const gold = Color(0xFFD6AD55);
const bg = Color(0xFF090A0D);
const panel = Color(0xFF17191F);

class V12App extends StatelessWidget {
  const V12App({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'V12',
      theme: ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: bg,
        colorScheme: ColorScheme.fromSeed(
          seedColor: gold, brightness: Brightness.dark,
          surface: panel,
        ),
        fontFamily: 'Roboto',
        useMaterial3: true,
      ),
      home: const HomeScreen(),
    );
  }
}

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int selected = 0;
  final pages = const [
    'الرئيسية', 'الرياضة', 'الأفلام', 'المسلسلات', 'القنوات'
  ];

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(
          backgroundColor: bg,
          title: const Text('V12', style: TextStyle(
            color: gold, fontSize: 27, fontWeight: FontWeight.w900,
            letterSpacing: 2,
          )),
          actions: [
            IconButton(
              tooltip: 'بحث',
              onPressed: () {},
              icon: const Icon(Icons.search, color: gold),
            ),
            IconButton(
              tooltip: 'المفضلة',
              onPressed: () {},
              icon: const Icon(Icons.bookmark_border, color: gold),
            ),
          ],
        ),
        body: selected == 0 ? const HomeContent() : CategoryContent(title: pages[selected]),
        bottomNavigationBar: NavigationBar(
          backgroundColor: const Color(0xFF111319),
          indicatorColor: gold.withOpacity(.18),
          selectedIndex: selected,
          onDestinationSelected: (i) => setState(() => selected = i),
          destinations: const [
            NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home, color: gold), label: 'الرئيسية'),
            NavigationDestination(icon: Icon(Icons.emoji_events_outlined), selectedIcon: Icon(Icons.emoji_events, color: gold), label: 'الرياضة'),
            NavigationDestination(icon: Icon(Icons.movie_outlined), selectedIcon: Icon(Icons.movie, color: gold), label: 'الأفلام'),
            NavigationDestination(icon: Icon(Icons.live_tv_outlined), selectedIcon: Icon(Icons.live_tv, color: gold), label: 'المسلسلات'),
            NavigationDestination(icon: Icon(Icons.satellite_alt_outlined), selectedIcon: Icon(Icons.satellite_alt, color: gold), label: 'القنوات'),
          ],
        ),
      ),
    );
  }
}

class HomeContent extends StatelessWidget {
  const HomeContent({super.key});

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 8, 16, 24),
      children: [
        Container(
          padding: const EdgeInsets.all(22),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(22),
            gradient: const LinearGradient(
              colors: [Color(0xFF39301F), Color(0xFF17191F), Color(0xFF101116)],
              begin: Alignment.topRight, end: Alignment.bottomLeft,
            ),
            border: Border.all(color: gold.withOpacity(.45)),
          ),
          child: const Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('عالمك في مكان واحد', style: TextStyle(color: Colors.white70, fontSize: 14)),
              SizedBox(height: 8),
              Text('V12 PREMIUM', style: TextStyle(
                color: gold, fontSize: 30, fontWeight: FontWeight.w900,
                letterSpacing: 1.5,
              )),
              SizedBox(height: 8),
              Text('الرياضة • الأفلام • المسلسلات • القنوات',
                style: TextStyle(color: Colors.white, fontSize: 13)),
            ],
          ),
        ),
        const SizedBox(height: 24),
        const SectionTitle(title: 'استكشف الأقسام'),
        const SizedBox(height: 12),
        const Wrap(
          spacing: 10, runSpacing: 10,
          children: [
            CategoryTile(icon: Icons.sports_soccer, title: 'الرياضة'),
            CategoryTile(icon: Icons.movie, title: 'الأفلام'),
            CategoryTile(icon: Icons.video_library, title: 'المسلسلات'),
            CategoryTile(icon: Icons.live_tv, title: 'القنوات المباشرة'),
          ],
        ),
        const SizedBox(height: 24),
        const SectionTitle(title: 'أضيف حديثاً'),
        const SizedBox(height: 10),
        const EmptyState(
          icon: Icons.play_circle_outline,
          title: 'مكتبتك تبدأ من هنا',
          subtitle: 'ستظهر هنا المواد والقنوات التي تضيفها من مصادر رسمية ومرخصة.',
        ),
        const SizedBox(height: 18),
        const SectionTitle(title: 'المباريات القادمة'),
        const MatchCard(home: 'الجزائر', away: 'تونس', competition: 'مباراة تجريبية • بيانات توضيحية', time: '20:00'),
        const MatchCard(home: 'ريال مدريد', away: 'برشلونة', competition: 'موعد تجريبي • غير مباشر', time: '21:30'),
        const SizedBox(height: 18),
        const SectionTitle(title: 'مشغل V12'),
        const Text('شغّل روابط الفيديو التي تملك حق استخدامها أو روابط مزود بث رسمي.',
          style: TextStyle(color: Colors.white60, fontSize: 12)),
        const SizedBox(height: 10),
        SizedBox(
          width: double.infinity,
          child: FilledButton.icon(
            style: FilledButton.styleFrom(backgroundColor: gold, foregroundColor: Colors.black),
            onPressed: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const PlayerScreen())),
            icon: const Icon(Icons.play_circle_fill),
            label: const Text('فتح مشغل الفيديو'),
          ),
        ),
      ],
    );
  }
}


class MatchCard extends StatelessWidget {
  final String home, away, competition, time;
  const MatchCard({super.key, required this.home, required this.away, required this.competition, required this.time});

  @override
  Widget build(BuildContext context) => Container(
    margin: const EdgeInsets.only(bottom: 9),
    padding: const EdgeInsets.all(14),
    decoration: BoxDecoration(color: panel, borderRadius: BorderRadius.circular(15),
      border: Border.all(color: gold.withOpacity(.18))),
    child: Row(children: [
      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(competition, style: const TextStyle(color: Colors.white54, fontSize: 11)),
        const SizedBox(height: 7),
        Text('$home  ×  $away', style: const TextStyle(fontWeight: FontWeight.bold)),
      ])),
      Column(children: [
        Text(time, style: const TextStyle(color: gold, fontWeight: FontWeight.bold)),
        const Text('توقيت تجريبي', style: TextStyle(color: Colors.white38, fontSize: 9)),
      ]),
    ]),
  );
}

class PlayerScreen extends StatefulWidget {
  const PlayerScreen({super.key});
  @override
  State<PlayerScreen> createState() => _PlayerScreenState();
}

class _PlayerScreenState extends State<PlayerScreen> {
  final urlController = TextEditingController();
  VideoPlayerController? controller;
  bool loading = false;
  String? error;

  Future<void> loadVideo() async {
    final url = urlController.text.trim();
    if (!(url.startsWith('https://') || url.startsWith('http://'))) {
      setState(() => error = 'أدخل رابط فيديو مباشر صحيح يبدأ بـ http أو https.');
      return;
    }
    setState(() { loading = true; error = null; });
    await controller?.dispose();
    final next = VideoPlayerController.networkUrl(Uri.parse(url));
    try {
      await next.initialize();
      await next.play();
      if (!mounted) { await next.dispose(); return; }
      setState(() { controller = next; loading = false; });
    } catch (_) {
      await next.dispose();
      if (!mounted) return;
      setState(() {
        loading = false;
        error = 'تعذر تشغيل الرابط. تأكد أنه رابط فيديو مدعوم ومصرح باستخدامه.';
      });
    }
  }

  @override
  void dispose() {
    urlController.dispose();
    controller?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('مشغل V12', style: TextStyle(color: gold))),
    body: ListView(padding: const EdgeInsets.all(16), children: [
      AspectRatio(
        aspectRatio: 16 / 9,
        child: Container(
          decoration: BoxDecoration(color: Colors.black, borderRadius: BorderRadius.circular(16),
            border: Border.all(color: gold.withOpacity(.35))),
          child: controller != null && controller!.value.isInitialized
            ? ClipRRect(
                borderRadius: BorderRadius.circular(16),
                child: Stack(alignment: Alignment.bottomCenter, children: [
                  Center(child: AspectRatio(
                    aspectRatio: controller!.value.aspectRatio,
                    child: VideoPlayer(controller!),
                  )),
                  VideoProgressIndicator(controller!, allowScrubbing: true,
                    colors: const VideoProgressColors(playedColor: gold)),
                  Positioned(right: 8, bottom: 18, child: IconButton(
                    onPressed: () => setState(() {
                      controller!.value.isPlaying ? controller!.pause() : controller!.play();
                    }),
                    icon: Icon(controller!.value.isPlaying ? Icons.pause : Icons.play_arrow,
                      color: Colors.white, size: 30),
                  )),
                ]),
              )
            : Center(child: loading
              ? const CircularProgressIndicator(color: gold)
              : const Column(mainAxisSize: MainAxisSize.min, children: [
                  Icon(Icons.play_circle_outline, color: gold, size: 54),
                  SizedBox(height: 8),
                  Text('V12 VIDEO PLAYER', style: TextStyle(color: Colors.white60)),
                ])),
        ),
      ),
      const SizedBox(height: 18),
      const Text('رابط الفيديو', style: TextStyle(fontWeight: FontWeight.bold)),
      const SizedBox(height: 8),
      TextField(
        controller: urlController,
        keyboardType: TextInputType.url,
        decoration: InputDecoration(
          hintText: 'https://example.com/video.m3u8',
          filled: true, fillColor: panel,
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
        ),
      ),
      const SizedBox(height: 10),
      FilledButton.icon(
        style: FilledButton.styleFrom(backgroundColor: gold, foregroundColor: Colors.black),
        onPressed: loading ? null : loadVideo,
        icon: const Icon(Icons.play_arrow),
        label: const Text('تشغيل'),
      ),
      if (error != null) Padding(
        padding: const EdgeInsets.only(top: 10),
        child: Text(error!, style: const TextStyle(color: Colors.orangeAccent)),
      ),
      const SizedBox(height: 12),
      const Text('يدعم المشغل روابط فيديو متوافقة مع Android. استخدم فقط روابطك أو روابط البث الرسمية المرخصة.',
        style: TextStyle(color: Colors.white54, fontSize: 12)),
    ]),
  );
}

class CategoryContent extends StatelessWidget {
  final String title;
  const CategoryContent({super.key, required this.title});

  @override
  Widget build(BuildContext context) => ListView(
    padding: const EdgeInsets.all(18),
    children: [
      Text(title, style: const TextStyle(color: gold, fontSize: 25, fontWeight: FontWeight.bold)),
      const SizedBox(height: 16),
      const EmptyState(
        icon: Icons.add_circle_outline,
        title: 'القسم جاهز للتطوير',
        subtitle: 'أضف محتوى من مزودين رسميين أو روابط بث تملك حق استخدامها.',
      ),
    ],
  );
}

class SectionTitle extends StatelessWidget {
  final String title;
  const SectionTitle({super.key, required this.title});
  @override
  Widget build(BuildContext context) => Text(title,
    style: const TextStyle(fontSize: 19, fontWeight: FontWeight.bold, color: Colors.white));
}

class CategoryTile extends StatelessWidget {
  final IconData icon;
  final String title;
  const CategoryTile({super.key, required this.icon, required this.title});

  @override
  Widget build(BuildContext context) => Container(
    width: 155, padding: const EdgeInsets.symmetric(vertical: 18, horizontal: 14),
    decoration: BoxDecoration(
      color: panel, borderRadius: BorderRadius.circular(16),
      border: Border.all(color: gold.withOpacity(.25)),
    ),
    child: Column(children: [
      Icon(icon, color: gold, size: 30),
      const SizedBox(height: 9),
      Text(title, textAlign: TextAlign.center,
        style: const TextStyle(fontWeight: FontWeight.w600)),
    ]),
  );
}

class EmptyState extends StatelessWidget {
  final IconData icon;
  final String title;
  final String subtitle;
  const EmptyState({super.key, required this.icon, required this.title, required this.subtitle});

  @override
  Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.all(18),
    decoration: BoxDecoration(color: panel, borderRadius: BorderRadius.circular(16)),
    child: Row(children: [
      Icon(icon, color: gold, size: 32),
      const SizedBox(width: 14),
      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(title, style: const TextStyle(fontWeight: FontWeight.bold)),
        const SizedBox(height: 5),
        Text(subtitle, style: const TextStyle(color: Colors.white60, fontSize: 12)),
      ])),
    ]),
  );
}
