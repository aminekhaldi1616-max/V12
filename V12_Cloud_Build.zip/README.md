# V12 Premium — Android cloud build

This repository is a Flutter Android starter for V12.

## Build an APK without a computer
1. Upload the contents of this folder to a GitHub repository.
2. Open the repository's **Actions** tab.
3. Select **Build V12 Android APK** and press **Run workflow** (or wait for the first push build).
4. Open the successful workflow run, scroll to **Artifacts**, and download `V12-release-apk`.
5. Extract the downloaded artifact ZIP on your Android phone. Install `app-release.apk`.

The workflow creates the Android platform folder, fetches Flutter packages, builds the release APK, and uploads it as an artifact.

Only use video URLs and content that you own or are licensed to stream. Match schedules shown in the starter app are illustrative placeholders, not live sports data.
